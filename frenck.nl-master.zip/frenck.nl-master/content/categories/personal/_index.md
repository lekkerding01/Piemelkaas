---
title: Personal articles and blog postings
seotitle: List of articles about my personal experiences
description: A list of articles and blog postings about personal stuff I've shared with the world. Some are about GTD/producivity, others about IoT experience, or about my personal life.
banner: banners/frenck.jpg
bannerTitle: Picture of Franck Nijhof / Frenck
keywords:
    - personal
    - experiences
    - iot
    - personal life
    - productivity
    - gtd
---

These articles listed below are about my personal life and experiences that I've
decided to share with the world. Some of those are about own experiences
using IoT devices in my Home Automation project, others about my obsession
with Getting Things Done/productivity. 

Once in a while, I might post something truly personal in this category as well.